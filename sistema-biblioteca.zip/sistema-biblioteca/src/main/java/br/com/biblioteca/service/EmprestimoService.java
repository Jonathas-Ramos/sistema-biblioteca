package br.com.biblioteca.service;

import br.com.biblioteca.model.*;
import br.com.biblioteca.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.time.LocalDate;

@Service
public class EmprestimoService {

    @Autowired
    private UsuarioRepository usuarioRepo;
    @Autowired
    private LivroRepository livroRepo;
    @Autowired
    private EmprestimoRepository emprestimoRepo;

    public void registrarEmprestimo(String usuarioId, String livroId) throws Exception {
        
        // 1. Busca o usuário e o livro exatos que vieram da tela HTML
        Usuario usuario = usuarioRepo.findById(usuarioId)
            .orElseThrow(() -> new Exception("Usuário não encontrado."));
            
        Livro livro = livroRepo.findById(livroId)
            .orElseThrow(() -> new Exception("Livro não encontrado."));

        // 2. REGRA DE NEGÓCIO: Bloqueia se a quantidade for 0 ou menor
        if (livro.getQuantidadeDisponivel() <= 0) {
            throw new Exception("Livro indisponível no momento.");
        }

        // 3. REGRA DE NEGÓCIO: Limite de empréstimos simultâneos (3 para Aluno, 5 para Professor)
        int limite = (usuario.getTipoPerfil() == TipoUsuario.ALUNO) ? 3 : 5;
        if (usuario.getQuantidadeEmprestimosAtivos() >= limite) {
            throw new Exception("Limite de empréstimos atingido para este usuário.");
        }

        // 4. Tudo certo! Cria o registro do empréstimo no banco
        Emprestimo emprestimo = new Emprestimo();
        emprestimo.setIdUsuario(usuario.getId());
        emprestimo.setIdLivro(livro.getId());
        emprestimo.setDataRetirada(LocalDate.now());
        emprestimo.setDataDevolucaoPrevista(LocalDate.now().plusDays(7)); // Prazo de 7 dias
        emprestimo.setEstaDevolvido(false);
        emprestimo.setValorMultaAtraso(0.0);
        emprestimoRepo.save(emprestimo);

        // 5. ATUALIZA OS ESTOQUES E SALVA
        livro.setQuantidadeDisponivel(livro.getQuantidadeDisponivel() - 1);
        livroRepo.save(livro);

        usuario.setQuantidadeEmprestimosAtivos(usuario.getQuantidadeEmprestimosAtivos() + 1);
        usuarioRepo.save(usuario);
    }
    
    // DEVOLVER LIVRO
    public void devolverEmprestimo(String emprestimoId) throws Exception {
        // 1. Busca o empréstimo no banco
        Emprestimo emprestimo = emprestimoRepo.findById(emprestimoId)
            .orElseThrow(() -> new Exception("Empréstimo não encontrado."));

        // 2. Verifica se já não foi devolvido antes
        if (emprestimo.isEstaDevolvido()) {
            throw new Exception("Este livro já consta como devolvido!");
        }

        // 3. Busca o Livro e o Usuário envolvidos
        Usuario usuario = usuarioRepo.findById(emprestimo.getIdUsuario()).orElseThrow();
        Livro livro = livroRepo.findById(emprestimo.getIdLivro()).orElseThrow();

        // 4. Marca como devolvido
        emprestimo.setEstaDevolvido(true);
        emprestimoRepo.save(emprestimo);

        // 5. Devolve o livro para a estante (+1)
        livro.setQuantidadeDisponivel(livro.getQuantidadeDisponivel() + 1);
        livroRepo.save(livro);

        // 6. Tira o empréstimo da conta do usuário (-1)
        usuario.setQuantidadeEmprestimosAtivos(usuario.getQuantidadeEmprestimosAtivos() - 1);
        usuarioRepo.save(usuario);
    }
}