package br.com.biblioteca.repository;

import br.com.biblioteca.model.Usuario;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository // Indica que esta classe é um componente de acesso a dados
public interface UsuarioRepository extends MongoRepository<Usuario, String> {
    // Ao estender MongoRepository, o Spring já cria automaticamente métodos como:
    // save(), findById(), findAll(), deleteById(), etc.
}