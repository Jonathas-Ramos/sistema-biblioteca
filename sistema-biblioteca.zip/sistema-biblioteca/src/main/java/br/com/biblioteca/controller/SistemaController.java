package br.com.biblioteca.controller;

import br.com.biblioteca.model.*;
import br.com.biblioteca.repository.*;
import br.com.biblioteca.service.EmprestimoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Controller
public class SistemaController {

    @Autowired
    private EmprestimoService emprestimoService;
    @Autowired
    private UsuarioRepository usuarioRepo;
    @Autowired
    private LivroRepository livroRepo;
    @Autowired
    private EmprestimoRepository emprestimoRepo; // Novo repositório adicionado

    // ==========================================
    // ROTAS DE TELA (GET) - Mostram as páginas
    // ==========================================

    // 1. Tela Inicial Limpa (Apenas o Menu)
    @GetMapping("/")
    public String paginaInicial() {
        return "index";
    }

    // 2. Nova Rota para o formulário de Empréstimo
    @GetMapping("/emprestar")
    public String formEmprestar(Model model) {
        model.addAttribute("listaUsuarios", usuarioRepo.findAll());
        model.addAttribute("listaLivros", livroRepo.findAll());
        return "emprestar-livro";
    }

    @GetMapping("/novo-usuario")
    public String formNovoUsuario() {
        return "adicionar-usuario";
    }

    @GetMapping("/novo-livro")
    public String formNovoLivro() {
        return "adicionar-livro";
    }

    @GetMapping("/devolver")
    public String formDevolverLivro(Model model) {
        List<Emprestimo> ativos = emprestimoRepo.findAll().stream()
                .filter(e -> !e.isEstaDevolvido())
                .collect(Collectors.toList());

        Map<String, String> listaDevolucao = new HashMap<>();
        for (Emprestimo emp : ativos) {
            String nomeUsuario = usuarioRepo.findById(emp.getIdUsuario()).map(Usuario::getNome).orElse("Desconhecido");
            String tituloLivro = livroRepo.findById(emp.getIdLivro()).map(Livro::getTitulo).orElse("Desconhecido");
            listaDevolucao.put(emp.getId(), tituloLivro + " (com " + nomeUsuario + ")");
        }

        model.addAttribute("listaDevolucao", listaDevolucao);
        return "devolver-livro";
    }

    // ==========================================
    // ROTAS DE AÇÃO (POST) - Salvam no Banco
    // ==========================================

    @PostMapping("/efetuar-emprestimo")
    public String realizarEmprestimo(@RequestParam String usuarioId, @RequestParam String livroId, Model model) {
        try {
            emprestimoService.registrarEmprestimo(usuarioId, livroId);
            model.addAttribute("mensagemSucesso", "Empréstimo realizado com sucesso! O estoque foi atualizado.");
        } catch (Exception e) {
            model.addAttribute("mensagemErro", "Erro ao emprestar: " + e.getMessage());
        }
        return "resultado";
    }

    @PostMapping("/salvar-usuario")
    public String salvarUsuario(@RequestParam String nome, @RequestParam TipoUsuario tipoPerfil, Model model) {
        Usuario u = new Usuario();
        u.setNome(nome);
        u.setTipoPerfil(tipoPerfil);
        u.setQuantidadeEmprestimosAtivos(0);
        usuarioRepo.save(u);
        model.addAttribute("mensagemSucesso", "Usuário " + nome + " cadastrado com sucesso!");
        return "resultado";
    }

    @PostMapping("/salvar-livro")
    public String salvarLivro(@RequestParam String titulo, @RequestParam int quantidade, Model model) {
        Livro l = new Livro();
        l.setTitulo(titulo);
        l.setQuantidadeDisponivel(quantidade);
        livroRepo.save(l);
        model.addAttribute("mensagemSucesso", "Livro '" + titulo + "' adicionado ao acervo com sucesso!");
        return "resultado";
    }

    @PostMapping("/efetuar-devolucao")
    public String efetuarDevolucao(@RequestParam String emprestimoId, Model model) {
        try {
            emprestimoService.devolverEmprestimo(emprestimoId);
            model.addAttribute("mensagemSucesso", "Livro devolvido com sucesso! O estoque foi restaurado.");
        } catch (Exception e) {
            model.addAttribute("mensagemErro", "Erro na devolução: " + e.getMessage());
        }
        return "resultado";
    }
}