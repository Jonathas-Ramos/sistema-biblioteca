package br.com.biblioteca.model;

public enum TipoUsuario { 
    ALUNO, 
    PROFESSOR 
}