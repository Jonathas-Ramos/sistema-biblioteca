package br.com.biblioteca.repository;

import br.com.biblioteca.model.Livro;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface LivroRepository extends MongoRepository<Livro, String> {
}