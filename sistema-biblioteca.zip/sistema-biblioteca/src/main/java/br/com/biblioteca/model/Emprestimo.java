package br.com.biblioteca.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import java.time.LocalDate;

@Document(collection = "emprestimos")
public class Emprestimo {
    @Id
    private String id;
    private String idUsuario;
    private String idLivro;
    private LocalDate dataRetirada;
    private LocalDate dataDevolucaoPrevista;
    private boolean estaDevolvido;
    private double valorMultaAtraso;

    // Getters e Setters
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getIdUsuario() { return idUsuario; }
    public void setIdUsuario(String idUsuario) { this.idUsuario = idUsuario; }
    public String getIdLivro() { return idLivro; }
    public void setIdLivro(String idLivro) { this.idLivro = idLivro; }
    public LocalDate getDataRetirada() { return dataRetirada; }
    public void setDataRetirada(LocalDate dataRetirada) { this.dataRetirada = dataRetirada; }
    public LocalDate getDataDevolucaoPrevista() { return dataDevolucaoPrevista; }
    public void setDataDevolucaoPrevista(LocalDate dataDevolucaoPrevista) { this.dataDevolucaoPrevista = dataDevolucaoPrevista; }
    public boolean isEstaDevolvido() { return estaDevolvido; }
    public void setEstaDevolvido(boolean estaDevolvido) { this.estaDevolvido = estaDevolvido; }
    public double getValorMultaAtraso() { return valorMultaAtraso; }
    public void setValorMultaAtraso(double valorMultaAtraso) { this.valorMultaAtraso = valorMultaAtraso; }
}