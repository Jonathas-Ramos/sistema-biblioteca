package com.example.sistema_biblioteca;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;

@SpringBootApplication
@ComponentScan(basePackages = "br.com.biblioteca") 
@EnableMongoRepositories(basePackages = "br.com.biblioteca.repository")
public class SistemaBibliotecaApplication {

    public static void main(String[] args) {
        // ESSA LINHA FORÇA O JAVA A USAR O SEU BANCO NOVO, IGNORANDO O NETBEANS
        System.setProperty("spring.data.mongodb.uri", "mongodb://localhost:27017/BibliotecaDB_Projeto");
        
        SpringApplication.run(SistemaBibliotecaApplication.class, args);
    }
}